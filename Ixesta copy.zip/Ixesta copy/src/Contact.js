import React, { Component } from 'react'

class Contact extends Component {
  render() {
    return (
      <div class='form-container'>
        <iframe
          class="form"
          id="JotFormIFrame-81943877197374"
          onload="window.parent.scrollTo(0,0)"
          allowtransparency="true"
          allowfullscreen="true"
          allow="geolocation;"
          src="https://form.jotformeu.com/81943877197374"
          frameborder="0"
          scrolling="yes"
        >
        </iframe>

      </div>
    )

  }
}

export default Contact;